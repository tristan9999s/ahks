# tbh idc about the source anything we went external.

> (Download) - https://www.autohotkey.com/download/ahk-install.exe

- if you skid it please give credits to me at least
- if your having any problems contact @ contact@tsurugi.cc
